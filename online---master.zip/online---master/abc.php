<!DOCTYPE html>
<html>
<head>
	<title>admin</title>
	<script type="text/javascript" src="script.js"></script>
</head>
<body>

	<form>
		DATE: <input id="datee" type="date" name="text">
		GENDER :<select id="gender">
			<option id="male">male</option>
			<option id="female">female</option>
				</select>
		<input type="submit" name="submit" onclick="abc()">
	</form>
</body>
</html>
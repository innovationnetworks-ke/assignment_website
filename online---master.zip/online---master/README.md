TITLE:ONLINE HOTEL MANAGEMENT SYSTEM.

AUTHOR.
[Ngugidavid](https://drongo-1.github.io/online--)

DESCRIPTION:
The Online hotel management system is developed using PHP, CSS, Javascript and Jquery.  

LIVE LINK.
https://drongo-1.github.io/online--

LICENCE.
MIT Licence.



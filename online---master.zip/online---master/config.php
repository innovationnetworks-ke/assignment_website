<?
$errors=array();

$conn=mysqli_connect('localhost', 'root','','user-registration') or die("could not connect".mysqli_error());

?>
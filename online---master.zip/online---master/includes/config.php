<?php
session_start();

	$conn=mysqli_connect('localhost', 'root', '	','onlinr') or die("could not connect".mysqli_error());	


?>

<script src='https://kit.fontawesome.com/a076d05399.js'></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<link rel="stylesheet" type="text/css" href="style.css">
<footer class="footer">
	<div class="footer1">
		<i class="fa fa-map-marker" style="font-size:36px;color: ;"></i>
		<p>Nairobi, Mombasa, </p>
		<p>Eldoret, Kisumu</p>
			
	</div>
	<div class="footer2">
		<i class="fa fa-phone" style="font-size:36px;color: ;"></i>
		<p>+254 798-305-620</p>
    <p>+254 746 395 881</p>
	</div>
	<div class="footer3">
		<i class="fa fa-envelope" style="font-size:36px;color: ;"></i>
		<p>ngugidavid46@gmail.com</p>
	</div>




	<div class="footer4">

    <!-- Social buttons -->
    <ul class="list-unstyled list-inline text-center">
      <li class="list-inline-item">
        <a class="btn-floating btn-fb mx-1">
          <i class="fab fa-facebook-f" style="font-size:20px;color: #3b5998;"> </i>
        </a>
      </li>
      <li class="list-inline-item">
        <a class="btn-floating btn-tw mx-1" >
          <i class="fab fa-twitter" style="font-size:20px;color:#00acee;"> </i>
        </a>
      </li>
      <li class="list-inline-item">
        <a class="btn-floating btn-gplus mx-1">
          <i class="fab fa-google-plus-g" style="font-size:17px;color: red;"> </i>
        </a>
      </li>
      <li class="list-inline-item">
        <a class="btn-floating btn-tw mx-1" >
          <i class="fab fa-youtube" style="font-size:20px;color:red;"> </i>
        </a>
      </li>
      <li class="list-inline-item">
        <a class="btn-floating btn-gplus mx-1">
          <i class="fab fa-snapchat" style="font-size:17px;color: yellow;"> </i>
        </a>
      </li>
    </ul>
    


  </div>
  <div class="footer5">
    	Copyright&copy;Prime Developers. All Rights Reserved.
    </div>	
</footer>





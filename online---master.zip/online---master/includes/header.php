<link rel="stylesheet" type="text/css" href="style.css">
<nav class="header">
	<input type="checkbox" id="checkbox">
	<label for="checkbox" class="checked">
		<i class="fas fa-bars""></i>
	</label>
	<label class="logo">PRIME DEVELOPERS</label>
		<ul>
			<li><a class="active" href="#">Home</a></li>
			<li><a href="#">Web services</a></li>
			<li><a href="#">About Us</a></li>
			<li><a href="#">Contacts</a></li>
			<li><a href="#">Feedback</a></li>
		</ul>
	</div>
 </nav>